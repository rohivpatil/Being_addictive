import { Component, OnInit } from '@angular/core';
declare var $ :any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  
    $(function () {
     $(".like").click(function () {
         var input = $(".like").find('.qty1');
         input.val(parseInt(input.val())+ 1);
     });

     $(".dislike").click(function () {
         var input = $(".dislike").find('.qty2');
         input.val(input.val() - 1);
     });
     $(".like1").click(function () {
      var input = $(".like1").find('.qty1');
      input.val(parseInt(input.val())+ 1);
  });

  $(".dislike1").click(function () {
      var input = $(".dislike1").find('.qty2');
      input.val(input.val() - 1);
  });
  $(".like2").click(function () {
    var input = $(".like2").find('.qty1');
    input.val(parseInt(input.val())+ 1);
});

$(".dislike2").click(function () {
    var input = $(".dislike2").find('.qty2');
    input.val(input.val() - 1);
});

$(".like3").click(function () {
  var input = $(".like").find('.qty1');
  input.val(parseInt(input.val())+ 1);
});

$(".dislike3").click(function () {
  var input = $(".dislike").find('.qty2');
  input.val(input.val() - 1);
});
$(".like4").click(function () {
  var input = $(".like").find('.qty1');
  input.val(parseInt(input.val())+ 1);
});

$(".dislike4").click(function () {
  var input = $(".dislike").find('.qty2');
  input.val(input.val() - 1);
});
    });

    $(window).on('load',function(){
     $(".loader-container").fadeOut(1000);
     //$(".content").fadeIn(1000);
    });
  }


}
